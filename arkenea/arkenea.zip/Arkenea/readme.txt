Original PSD template provided by Prashant Dwivedi (https://dribbble.com/shots/2218540-Arkenea)
HTML conversion by Nam Vu (https://namvu.net/freebies-arkenea-html-template/)